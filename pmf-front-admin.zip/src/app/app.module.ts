import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { OAuthModule } from 'angular-oauth2-oidc';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ApiService } from './providers/services/api/api.service';
import { TokenInterceptorInterceptor } from '../core/shared/common/interceptor/http.interceptor';
import { BlankLayoutModule, MainLayoutModule } from './main/layouts/index';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthService } from './providers/services/auth/auth.service';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRoutingModule,
    MainLayoutModule,
    BlankLayoutModule,
    OAuthModule.forRoot({
      resourceServer: {
        allowedUrls: ['http://localhost:5001/pages/'],
        sendAccessToken: true,
      },
    }),
  ],
  providers: [
    AuthService,
    ApiService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
