import { Component } from '@angular/core';
import { OAuthService, JwksValidationHandler } from 'angular-oauth2-oidc';
import { Router } from '@angular/router';
import { LocalStorageService } from '../core/shared/common/services/storage/local-storage.service';
import { SessionStorageService } from '../core/shared/common/services/storage/session-storage.service';
import { AuthService } from './providers/services/auth/auth.service';
import { authConfig } from './settings/constants/auth-config';

@Component({
  selector: 'pmf-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'pmf-front-admin';
  modules: any;
  claims: any;
  token: string;

  constructor(
    private readonly oauthService: OAuthService,
    private readonly dataApi: AuthService,
    private readonly localStorageService: LocalStorageService,
    private readonly sessionStorageService: SessionStorageService,
    private readonly router: Router,
  ) {
    this.oauthService.configure(authConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    if (window.location.pathname !== '/') {
      this.sessionStorageService.setItem('redirectURL', String(window.location.pathname));
    }
    this.oauthService.loadDiscoveryDocumentAndLogin().then(() => {
      if (this.oauthService.hasValidAccessToken()) {
        this.claims = this.oauthService.getIdentityClaims();
        if (!this.localStorageService.getItem('Token')) {
          this.dataApi.getToken().subscribe(
            (data: any) => {
              this.localStorageService.setItem('Token', data.PMFToken);
              this.localStorageService.setItem('RefreshToken', data.RefreshToken);
              this.getmodules();
            },
            () => {
              this.modules = [];
              const currentUser = {
                email: this.claims.preferred_username,
                name: this.claims.name,
                modules: this.modules,
              };
              this.dataApi.setModulesUser(this.modules);
              this.localStorageService.setItem('currentUser', JSON.stringify(currentUser));
            },
          );
        } else {
          this.getmodules();
        }
      } else {
      }
    });
  }

  private getmodules(): void {
    this.dataApi.getModules().subscribe(
      (data: any) => {
        this.modules = data;
        const currentUser = {
          email: this.claims.preferred_username,
          name: this.claims.name,
          modules: this.modules,
        };
        this.dataApi.setModulesUser(this.modules);
        this.localStorageService.setItem('currentUser', JSON.stringify(currentUser));
        if (this.sessionStorageService.getItem('redirectURL') != null) {
          this.router.navigate([this.sessionStorageService.getItem('redirectURL')]);
          this.sessionStorageService.removeItem('redirectURL');
        }
      },
      () => {
        this.modules = [];
        const currentUser = {
          email: this.claims.preferred_username,
          name: this.claims.name,
          modules: this.modules,
          jwtToken: this.token,
        };
        this.dataApi.setModulesUser(this.modules);
        this.localStorageService.setItem('currentUser', JSON.stringify(currentUser));
      },
    );
  }
}
