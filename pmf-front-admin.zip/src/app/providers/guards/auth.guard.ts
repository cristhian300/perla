import { Injectable } from '@angular/core';
import { CanActivate, UrlTree, CanActivateChild, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LocalStorageService } from 'src/core/shared/common/services/storage';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(private router: Router, private readonly localStorageService: LocalStorageService) {
    // ctor
  }

  canActivate(): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    const currentUser = this.localStorageService.getItemObject<{ modules: Array<number> }>('currentUser');
    if (!currentUser.modules.some((m) => m === 100 || m === 101 || m === 102 || m === 103)) {
      this.router.navigate(['not-authorization']);
      return false;
    }
    return true;
  }

  canActivateChild(): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return true;
  }
}
