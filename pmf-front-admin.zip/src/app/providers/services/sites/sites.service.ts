import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiService } from '../api/api.service';
import { ISiteResponse } from './sites.interface';

@Injectable({
  providedIn: 'root',
})
export class SitesService {
  urlBase: string;
  constructor(private readonly apiService: ApiService) {
    this.urlBase = `${environment.bffBaseUrl}/api/site`;
  }

  getAll(): Observable<ISiteResponse> {
    return this.apiService.get(this.urlBase);
  }
}
