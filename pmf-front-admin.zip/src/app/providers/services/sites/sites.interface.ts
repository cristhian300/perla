export interface ISite {
  id: number;
  name: string;
  description: string;
  countryId: number;
  isEnabled: boolean;
}

export type ISiteResponse = Array<ISite>;
