export interface IPaginatorResponse<T> {
  paginator: { page: string; limit: string; totalPages: string; totalItems: string };
  items: Array<T>;
}
