import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiService } from '../api/api.service';
import { IManageZoneRequest, IQualificationZone, IZone, IZoneResponse } from './zones.interfaces';

@Injectable({
  providedIn: 'root',
})
export class ZonesService {
  private urlBase: string;
  private urlBaseZone: string;
  constructor(private readonly apiService: ApiService) {
    this.urlBase = `${environment.bffBaseUrl}/api/site`;
    this.urlBaseZone = `${environment.bffBaseUrl}/api/zone`;
  }

  public getZoneWithSubzonesBySite(siteId: number): Observable<IZoneResponse> {
    return this.apiService.get(`${this.urlBase}/${siteId}/zonewithsubzone`);
  }
  public createZoneWithQualifications(zone: IZone, qualificationsZone: Array<IQualificationZone>): Observable<IZone> {
    const zoneRequest: IManageZoneRequest = {
      zone,
      lstQualification: qualificationsZone,
    };
    return this.apiService.post(`${this.urlBaseZone}/withqualification`, zoneRequest);
  }
}
