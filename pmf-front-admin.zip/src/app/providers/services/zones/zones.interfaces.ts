export interface IZone {
  id?: number;
  name?: string;
  siteId?: number;
  isEnabled?: boolean;
  description?: string;
  subZone?: Array<ISubZone>;
}

export interface ISubZone {
  id?: number;
  zoneId?: number;
  name?: string;
  description?: string;
  isEnabled?: boolean;
}

export interface IQualificationZone {
  id?: number;
  name?: string;
  codeCommandCentre?: string;
  isActive?: boolean;
}

export interface IManageZoneRequest {
  zone: IZone;
  lstQualification: Array<IQualificationZone>;
}

export type IZoneResponse = Array<IZone>;
