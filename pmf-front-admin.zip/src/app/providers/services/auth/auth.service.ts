import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { OAuthService } from 'angular-oauth2-oidc';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { ApiService } from '../api/api.service';
import { CustomsValidators } from 'src/core/shared/helpers/util/custom-validators';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  urlSarAz: string;
  urlPMFToken: string; // URL SAR TOKEN
  urlLogout: string; // URL SAR logout
  modules: Array<number> = [];
  modulesSubject: BehaviorSubject<Array<number>>;
  modules$: Observable<Array<number>>;
  constructor(private readonly apiService: ApiService, private readonly oauthService: OAuthService) {
    this.urlSarAz = `${environment.bffBaseUrl}/pmf/groups/`;
    this.urlLogout = `${environment.bffBaseUrl}/pmf/auth/logout/`;
    this.urlPMFToken = `${environment.bffBaseUrl}/pmf/auth`;
    this.modulesSubject = new BehaviorSubject<any>(this.modules);
    this.modules$ = this.modulesSubject.asObservable();
  }

  getModules() {
    let header = new HttpHeaders();
    header = header.set('AzureToken', this.oauthService.getAccessToken());
    const urlBuilder = this.urlSarAz;
    return CustomsValidators.isValidUrl(urlBuilder)
      ? this.apiService.get(urlBuilder, { headers: header })
      : throwError(CustomsValidators.msgNotValidUrl);
  }

  getModulesUser() {
    return this.modules$;
  }

  setModulesUser(modules) {
    this.modulesSubject.next(modules);
  }

  refreshToken() {
    const item = {
      pmfToken: localStorage.Token,
      refreshToken: localStorage.RefreshToken,
    };
    const urlBuilder = `${environment.bffBaseUrl}/pmf/auth/refresh`;
    return CustomsValidators.isValidUrl(urlBuilder)
      ? this.apiService.post(urlBuilder, item)
      : throwError(CustomsValidators.msgNotValidUrl);
  }

  getToken() {
    const urlBuilder = this.urlPMFToken;
    return CustomsValidators.isValidUrl(urlBuilder)
      ? this.apiService.get(urlBuilder)
      : throwError(CustomsValidators.msgNotValidUrl);
  }

  logout() {
    const urlBuilder = this.urlLogout;
    return CustomsValidators.isValidUrl(urlBuilder)
      ? this.apiService.post(urlBuilder, { pmfToken: localStorage.Token })
      : throwError(CustomsValidators.msgNotValidUrl);
  }
}
