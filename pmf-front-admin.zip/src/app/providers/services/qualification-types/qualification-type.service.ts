import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiService } from '../api/api.service';
import { IQualificationTypeResponse } from './qualification-type.interface';

@Injectable({
  providedIn: 'root',
})
export class QualificationTypeService {
  urlBase: string;
  constructor(private readonly apiService: ApiService) {
    this.urlBase = `${environment.bffBaseUrl}/pages/qualifications/qualificationtype`;
  }

  getAllActives(): Observable<IQualificationTypeResponse> {
    const url = `${this.urlBase}/1`;
    return this.apiService.get(url);
  }
}
