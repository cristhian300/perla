export interface IQualificationType {
  id: number;
  name: string;
  isActive: string;
}

export type IQualificationTypeResponse = Array<IQualificationType>;
