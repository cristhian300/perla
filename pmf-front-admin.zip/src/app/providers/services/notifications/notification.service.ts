import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

enum NotificationState {
  success,
  failure,
  hide,
}

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  notification: any = { title: '', subtitle: '', severity: 'hide' };
  notificationSubject = new BehaviorSubject<any>(this.notification);
  notification$ = this.notificationSubject.asObservable();

  async fire(type: string, title: string, subtitle: string, autoClose = false, timeToClose = 0) {
    if (!(type in NotificationState)) {
      type = 'success';
    }
    this.notificationSubject.next({ title, subtitle, severity: type });
    if (autoClose) {
      setTimeout(() => {
        this.hide();
      }, timeToClose);
    }
  }

  async hide() {
    this.notificationSubject.next({ ...this.notification, severity: 'hide' });
  }
}
