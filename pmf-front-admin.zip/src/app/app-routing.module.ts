import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainLayoutComponent } from './main/layouts';

const routes: Routes = [
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () => import('./main/views/main-menu/main-menu.module').then((m) => m.MainMenuModule),
      },
      {
        path: 'sys-req',
        loadChildren: () =>
          import('./main/views/system-requirement/system-requirement.module').then((m) => m.SystemRequirementModule),
      },
      {
        path: 'admin-zone',
        data: {
          breadcrumb: 'Administración de zonas y sub-zonas de sitios',
        },
        loadChildren: () =>
          import('./main/views/zone-management/zone-management.module').then((m) => m.ZoneManagementModule),
      },
      {
        path: 'assign-zone',
        loadChildren: () =>
          import('./main/views/assignment-zone/assignment-zone.module').then((m) => m.AssignmentZoneModule),
      },
      {
        path: 'assign-subzone',
        loadChildren: () =>
          import('./main/views/assignment-subzone/assignment-subzone.module').then((m) => m.AssignmentSubzoneModule),
      },
    ],
  },
  {
    path: 'styleguide',
    loadChildren: () =>
      import('./main/views/style-guideline/style-guideline.module').then((m) => m.StyleGuidelineModule),
  },
  {
    path: 'not-authorization',
    loadChildren: () =>
      import('./main/pages/not-authorization/not-authorization.module').then((m) => m.NotAuthorizationModule),
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
