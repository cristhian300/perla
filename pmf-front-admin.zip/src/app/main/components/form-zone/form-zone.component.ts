import { Component } from '@angular/core';

@Component({
  selector: 'pmf-form-zone',
  templateUrl: './form-zone.component.html',
  styleUrls: ['./form-zone.component.scss'],
})
export class FormZoneComponent {}
