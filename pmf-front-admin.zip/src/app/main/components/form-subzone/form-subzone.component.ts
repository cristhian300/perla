import { Component } from '@angular/core';

@Component({
  selector: 'pmf-form-subzone',
  templateUrl: './form-subzone.component.html',
  styleUrls: ['./form-subzone.component.scss'],
})
export class FormSubzoneComponent {}
