import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormSubzoneComponent } from './form-subzone.component';

describe('FormSubzoneComponent', () => {
  let component: FormSubzoneComponent;
  let fixture: ComponentFixture<FormSubzoneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FormSubzoneComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FormSubzoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
