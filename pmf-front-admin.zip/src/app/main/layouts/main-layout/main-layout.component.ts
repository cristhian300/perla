import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { NotificationService } from 'src/app/providers/services/notifications/notification.service';
import { SharedDataService } from 'src/core/shared/common/services/shared-data/shared-data.service';
import { BreadcrumbsComponent } from 'src/core/ui/components/breadcrumbs/breadcrumbs.component';
import { IBreadcrums } from 'src/core/ui/components/breadcrumbs/breadcrumbs.interface';

@Component({
  selector: 'pmf-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss'],
})
export class MainLayoutComponent implements OnInit {
  menu: any = [
    {
      label: 'Administración PMF',
      routerLink: [],
    },
  ];

  menuTop: any = [
    {
      label: 'Ayuda',
      routerLink: ['/'],
    },
  ];

  title = '';
  subtitle = '';
  breadcrumbHomeName = 'Inicio';
  breadcrumbs = [];

  notif: any = {
    title: '',
    subtitle: '',
    severity: '',
  };

  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private sharedData: SharedDataService,
    private notificationService: NotificationService,
  ) {
    this.sharedData.currentTitleObj.subscribe((obj) => {
      this.title = obj.title;
      this.subtitle = obj.subtitle;
    });
    this.notificationService.notification$.subscribe((notification) => {
      this.notif.title = notification.title;
      this.notif.subtitle = notification.subtitle;
      this.notif.severity = notification.severity;
    });
  }

  ngOnInit(): void {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe(() => (this.breadcrumbs = this.createBreadcrumbs(this.activateRoute)));
  }

  private createBreadcrumbs(route: ActivatedRoute, url: string = '/', breadcrumbs: IBreadcrums = []): Array<any> {
    const children: Array<ActivatedRoute> = route.children;

    if (!children.length) {
      return breadcrumbs;
    }

    for (const child of children) {
      const routerUrl = child.snapshot.url.map((segment) => segment.path).join('/');
      if (routerUrl) {
        url += `/${routerUrl}`;
      }

      const label = child.snapshot.data[BreadcrumbsComponent.ROUTE_DATA_BREADCRUMB];
      if (label) {
        breadcrumbs = [...breadcrumbs, { label, url }];
      }
      return this.createBreadcrumbs(child, url, breadcrumbs);
    }
  }
}
