import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HeaderModule } from 'src/core/ui/components/header/header.module';
import { BreadcrumbsModule } from 'src/core/ui/components/breadcrumbs/breadcrumbs.module';
import { FooterModule } from 'src/core/ui/components/footer/footer.module';
import { MainLayoutComponent } from './main-layout.component';
import { TitleBarModule } from 'src/core/ui/components/title-bar/title-bar.module';
import { NotificationModule } from 'src/core/ui/components/notification/notification.module';

@NgModule({
  declarations: [MainLayoutComponent],
  imports: [
    CommonModule,
    RouterModule,
    HeaderModule,
    BreadcrumbsModule,
    FooterModule,
    TitleBarModule,
    NotificationModule,
  ],
})
export class MainLayoutModule {}
