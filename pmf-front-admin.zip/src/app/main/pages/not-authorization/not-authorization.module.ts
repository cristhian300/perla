import { NgModule } from '@angular/core';
import { NotAuthorizationComponent } from './not-authorization.component';
import { NotAuthorizationRoutingModule } from './not-authorization.routing';

@NgModule({
  declarations: [NotAuthorizationComponent],
  imports: [NotAuthorizationRoutingModule],
})
export class NotAuthorizationModule {}
