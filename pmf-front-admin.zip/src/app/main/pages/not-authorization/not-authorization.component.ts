import { Component } from '@angular/core';

@Component({
  selector: 'pmf-not-found',
  templateUrl: './not-authorization.component.html',
  styleUrls: ['./not-authorization.component.scss'],
})
export class NotAuthorizationComponent {}
