import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotAuthorizationComponent } from './not-authorization.component';

const routes: Routes = [
  {
    path: '',
    component: NotAuthorizationComponent,
  },
];

@NgModule({
  declarations: [],
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NotAuthorizationRoutingModule {}
