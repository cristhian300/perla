import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StyleGuidelineComponent } from './style-guideline.component';
import { StyleGuidelineRoutingModule } from './style-guideline.routing';
import { HeaderModule } from 'src/core/ui/components/header/header.module';
import { FooterModule } from 'src/core/ui/components/footer/footer.module';
import { BreadcrumbsModule } from 'src/core/ui/components/breadcrumbs/breadcrumbs.module';
import { CardmenuModule } from 'src/core/ui/components/cardmenu/cardmenu.module';
import { TitleBarModule } from 'src/core/ui/components/title-bar/title-bar.module';
import { ZoneBlockModule } from 'src/app/main/views/zone-management/zone-block/zone-block.module';
import { ButtonModule } from 'src/core/ui/components/button/button.module';
import { ModalZoneModule } from 'src/core/ui/components/modal-zone/modal-zone.module';

@NgModule({
  declarations: [StyleGuidelineComponent],
  imports: [
    CommonModule,
    StyleGuidelineRoutingModule,
    HeaderModule,
    FooterModule,
    BreadcrumbsModule,
    CardmenuModule,
    TitleBarModule,
    ZoneBlockModule,
    ButtonModule,
    ModalZoneModule,
  ],
})
export class StyleGuidelineModule {}
