import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StyleGuidelineComponent } from './style-guideline.component';

describe('StyleGuidelineComponent', () => {
  let component: StyleGuidelineComponent;
  let fixture: ComponentFixture<StyleGuidelineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [StyleGuidelineComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StyleGuidelineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
