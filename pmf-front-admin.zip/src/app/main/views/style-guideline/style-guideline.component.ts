import { Component } from '@angular/core';

@Component({
  selector: 'pmf-style-guideline',
  templateUrl: './style-guideline.component.html',
  styleUrls: ['./style-guideline.component.scss'],
})
export class StyleGuidelineComponent {
  cards: any = [
    {
      label: 'Requisitos del sistema',
      routerLink: ['/'],
    },
    {
      label: 'Administración de zonas y sub-zonas de sitios',
      routerLink: ['/'],
    },
    {
      label: 'Asignación de requisitos a zonas',
      routerLink: ['/'],
    },
    {
      label: 'Asignación de requisitos a sub-zonas',
      routerLink: ['/'],
    },
  ];

  menu: any = [
    {
      label: 'Proveedores',
      routerLink: ['/'],
    },
    {
      label: 'Contrato',
      routerLink: [],
    },
    {
      label: 'Contratistas',
      routerLink: [],
    },
    {
      label: 'Requisitos',
      routerLink: [],
    },
  ];

  menuTop: any = [
    {
      label: 'Ayuda',
      routerLink: [],
    },
  ];

  btnLabel = 'Agregar nueva zona';
  btnItemLabel = 'Agregar nueva sub-zona';

  title = 'Administración PMF';
  subtitle = 'Selecciona la sección que quieres administrar';

  breadcrumb: any = [
    {
      label: 'Inicio',
      routerLink: ['/'],
    },
  ];

  tableTitles: any[] = [
    {
      title: 'Sub-zona',
      class: 'col-lg-3',
      field: 'name',
    },
    {
      title: 'Descripción',
      class: 'col-lg-4',
      field: 'description',
    },
    {
      title: 'Estado',
      class: 'col-lg-2',
      field: 'status',
    },
    {
      title: 'Acciones',
      class: 'col-lg-3',
      field: 'actions',
    },
  ];

  zones: any[] = [
    {
      name: 'Mel Faena',
      status: 1,
      subzones: [
        {
          name: 'Planta Los Colorados',
          description: 'Esta es una description temporal',
          status: 1,
          actions: ['edit', 'delete'],
        },
      ],
      actions: ['edit', 'delete'],
    },
    {
      name: 'La escondida',
      status: 0,
      subzones: [
        {
          name: 'Planta Santa Rosa',
          description: 'Esta es una description temporal',
          status: 1,
          actions: ['edit', 'delete'],
        },
      ],
      actions: ['edit', 'delete'],
    },
  ];
}
