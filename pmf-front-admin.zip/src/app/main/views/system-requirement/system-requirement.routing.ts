import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SystemRequirementComponent } from './system-requirement.component';

const routes: Routes = [
  {
    path: '',
    component: SystemRequirementComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SystemRequirementRoutingModule {}
