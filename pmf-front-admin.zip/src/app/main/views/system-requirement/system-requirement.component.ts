import { Component } from '@angular/core';

@Component({
  selector: 'pmf-system-requirement',
  templateUrl: './system-requirement.component.html',
  styleUrls: ['./system-requirement.component.scss'],
})
export class SystemRequirementComponent {}
