import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemRequirementComponent } from './system-requirement.component';

describe('SystemRequirementComponent', () => {
  let component: SystemRequirementComponent;
  let fixture: ComponentFixture<SystemRequirementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SystemRequirementComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemRequirementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
