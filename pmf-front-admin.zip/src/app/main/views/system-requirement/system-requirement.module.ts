import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SystemRequirementComponent } from './system-requirement.component';
import { SystemRequirementRoutingModule } from './system-requirement.routing';

@NgModule({
  declarations: [SystemRequirementComponent],
  imports: [CommonModule, SystemRequirementRoutingModule],
})
export class SystemRequirementModule {}
