import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignmentSubzoneComponent } from './assignment-subzone.component';

describe('AssignmentSubzoneComponent', () => {
  let component: AssignmentSubzoneComponent;
  let fixture: ComponentFixture<AssignmentSubzoneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AssignmentSubzoneComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignmentSubzoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
