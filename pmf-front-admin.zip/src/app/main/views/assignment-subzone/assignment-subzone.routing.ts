import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignmentSubzoneComponent } from './assignment-subzone.component';

const routes: Routes = [
  {
    path: '',
    component: AssignmentSubzoneComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssignmentSubzoneRoutingModule {}
