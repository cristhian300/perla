import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssignmentSubzoneRoutingModule } from './assignment-subzone.routing';

@NgModule({
  declarations: [],
  imports: [CommonModule, AssignmentSubzoneRoutingModule],
})
export class AssignmentSubzoneModule {}
