import { Component } from '@angular/core';

@Component({
  selector: 'pmf-assignment-subzone',
  templateUrl: './assignment-subzone.component.html',
  styleUrls: ['./assignment-subzone.component.scss'],
})
export class AssignmentSubzoneComponent {}
