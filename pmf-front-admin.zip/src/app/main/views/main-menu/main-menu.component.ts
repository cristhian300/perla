import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/providers/services/auth/auth.service';
import { SharedDataService } from 'src/core/shared/common/services/shared-data/shared-data.service';
import { LocalStorageService } from 'src/core/shared/common/services/storage';

@Component({
  selector: 'pmf-main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: ['./main-menu.component.scss'],
})
export class MainMenuComponent implements OnInit {
  cards: any = [];

  titleObj = {
    title: 'Administración PMF',
    subtitle: 'Selecciona la sección que quieres administrar',
  };

  constructor(
    private sharedData: SharedDataService,
    private readonly localStorageService: LocalStorageService,
    private authService: AuthService,
  ) {
    // ctor here.
    this.authService.getModulesUser().subscribe((modules) => {
      if (modules.some((m) => m === 100 || m === 101 || m === 102 || m === 103)) {
        this.cards = [
          {
            label: 'Requisitos del sistema',
            routerLink: ['/sys-req'],
          },
          {
            label: 'Administración de zonas y sub-zonas de sitios',
            routerLink: ['/admin-zone'],
          },
          {
            label: 'Asignación de requisitos a zonas',
            routerLink: ['/assign-zone'],
          },
          {
            label: 'Asignación de requisitos a sub-zonas',
            routerLink: ['/assign-subzone'],
          },
        ];
      }
    });
  }

  ngOnInit() {
    setTimeout(() => {
      this.sharedData.setTitleObj(this.titleObj);
    }, 0);
  }
}
