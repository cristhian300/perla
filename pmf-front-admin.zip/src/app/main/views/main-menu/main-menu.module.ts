import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainMenuComponent } from './main-menu.component';
import { MainMenuRoutingModule } from './main-menu.routing';
import { CardmenuModule } from 'src/core/ui/components/cardmenu/cardmenu.module';

@NgModule({
  declarations: [MainMenuComponent],
  imports: [CommonModule, MainMenuRoutingModule, CardmenuModule],
})
export class MainMenuModule {}
