import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZoneModalFormComponent } from './zone-modal-form.component';

describe('ZoneModalFormComponent', () => {
  let component: ZoneModalFormComponent;
  let fixture: ComponentFixture<ZoneModalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ZoneModalFormComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ZoneModalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
