import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ZoneItemComponent } from './zone-item.component';

@NgModule({
  declarations: [ZoneItemComponent],
  imports: [CommonModule],
  exports: [ZoneItemComponent],
})
export class ZoneItemModule {}
