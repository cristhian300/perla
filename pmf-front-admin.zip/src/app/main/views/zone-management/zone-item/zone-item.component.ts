import { Component, Input } from '@angular/core';
import { ISubZone } from 'src/app/providers/services/zones/zones.interfaces';

@Component({
  selector: 'pmf-zone-item',
  templateUrl: './zone-item.component.html',
  styleUrls: ['./zone-item.component.scss'],
})
export class ZoneItemComponent {
  @Input() subZone: ISubZone = {};
  @Input() titles: any[] = [];

  get status(): string {
    return (this.subZone?.isEnabled && 'Activo') || 'Inactivo';
  }
}
