import { Component, OnInit } from '@angular/core';
import { ISite, ISiteResponse } from 'src/app/providers/services/sites/sites.interface';
import { SitesService } from 'src/app/providers/services/sites/sites.service';
import { IZone, IZoneResponse } from 'src/app/providers/services/zones/zones.interfaces';
import { ZonesService } from 'src/app/providers/services/zones/zones.service';
import { SharedDataService } from 'src/core/shared/common/services/shared-data/shared-data.service';

@Component({
  selector: 'pmf-zone-management',
  templateUrl: './zone-management.component.html',
  styleUrls: ['./zone-management.component.scss'],
})
export class ZoneManagementComponent implements OnInit {
  btnLabel = 'Agregar nueva zona';
  btnItemLabel = 'Agregar nueva sub-zona';
  showZoneModalForm = false;
  tableTitles: any[] = [
    {
      title: 'Sub-zona',
      class: 'col-lg-3',
      field: 'name',
    },
    {
      title: 'Descripción',
      class: 'col-lg-4',
      field: 'description',
    },
    {
      title: 'Estado',
      class: 'col-lg-2',
      field: 'status',
    },
    {
      title: 'Acciones',
      class: 'col-lg-3',
      field: 'actions',
    },
  ];

  titleObj = {
    title: 'Administración de zonas y sub-zonas de sitios',
    subtitle: 'En esta sección puedes gestionar las zonas y sub-zonas de un sitio.',
  };

  nofitTitle = 'La sub-zona ha sido actualizada con éxito';
  notifSubtitle = 'Se acaba de actualizar la información de la sub-zona "Planta Los Colorados"';

  siteSelected = '';
  site: ISite;
  zones: Array<IZone> = [];
  sites: Array<ISite> = [];

  constructor(
    private sharedData: SharedDataService,
    private sitesService: SitesService,
    private zoneService: ZonesService,
  ) {
    // ctor here.
  }

  ngOnInit() {
    setTimeout(() => {
      this.sharedData.setTitleObj(this.titleObj);
    }, 0);
    this.loadSites();
  }

  onSiteChange(): void {
    this.loadZones();
  }

  openCreateZoneForm(): void {
    this.site = this.sites.find((x) => x.id === parseInt(this.siteSelected, 10));
    this.showZoneModalForm = !this.showZoneModalForm;
  }

  private loadSites(): void {
    this.sitesService.getAll().subscribe((response: ISiteResponse) => {
      this.sites = response;
      this.siteSelected = (response[0] && response[0].id.toString()) || '';
      this.loadZones();
    });
  }

  private loadZones(): void {
    if (this.siteSelected) {
      this.zoneService.getZoneWithSubzonesBySite(+this.siteSelected).subscribe((response: IZoneResponse) => {
        this.zones = response;
      });
    } else {
      this.zones = [];
    }
  }
}
