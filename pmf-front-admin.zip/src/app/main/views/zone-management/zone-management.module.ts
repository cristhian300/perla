import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ZoneManagementComponent } from './zone-management.component';
import { ZoneManagementRoutingModule } from './zone-management.routing';
import { ButtonModule } from 'src/core/ui/components/button/button.module';
import { ZoneBlockModule } from './zone-block/zone-block.module';
import { ZoneModalFormComponent } from './zone-modal-form/zone-modal-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiSelectModule } from 'primeng/multiselect';
import { SubzoneModalFormComponent } from './subzone-modal-form/subzone-modal-form.component';

@NgModule({
  declarations: [ZoneManagementComponent, ZoneModalFormComponent, SubzoneModalFormComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ZoneManagementRoutingModule,
    ZoneBlockModule,
    ButtonModule,
    MultiSelectModule,
  ],
})
export class ZoneManagementModule {}
