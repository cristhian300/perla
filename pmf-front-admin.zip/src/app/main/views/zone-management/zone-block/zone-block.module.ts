import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ZoneBlockComponent } from './zone-block.component';
import { ZoneItemModule } from './../zone-item/zone-item.module';
import { ButtonModule } from 'src/core/ui/components/button/button.module';

@NgModule({
  declarations: [ZoneBlockComponent],
  imports: [CommonModule, ButtonModule, ZoneItemModule],
  exports: [ZoneBlockComponent],
})
export class ZoneBlockModule {}
