import { Component, Input } from '@angular/core';
import { IZone } from 'src/app/providers/services/zones/zones.interfaces';

@Component({
  selector: 'pmf-zone-block',
  templateUrl: './zone-block.component.html',
  styleUrls: ['./zone-block.component.scss'],
})
export class ZoneBlockComponent {
  @Input() btnLabel = '';
  @Input() btnItemLabel = '';
  @Input() showButton = true;
  @Input() showItemButton = true;
  @Input() tableTitles: any[] = [];
  @Input() zone: IZone = {};

  get status(): string {
    return (this.zone?.isEnabled && 'Activo') || 'Inactivo';
  }
}
