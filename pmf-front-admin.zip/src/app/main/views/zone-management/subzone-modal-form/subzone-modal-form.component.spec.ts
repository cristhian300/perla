import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubzoneModalFormComponent } from './subzone-modal-form.component';

describe('SubzoneModalFormComponent', () => {
  let component: SubzoneModalFormComponent;
  let fixture: ComponentFixture<SubzoneModalFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SubzoneModalFormComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubzoneModalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
