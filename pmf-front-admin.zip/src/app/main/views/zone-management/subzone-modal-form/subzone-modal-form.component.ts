import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from 'src/app/providers/services/notifications/notification.service';
import {
  IQualificationType,
  IQualificationTypeResponse,
} from 'src/app/providers/services/qualification-types/qualification-type.interface';
import { QualificationTypeService } from 'src/app/providers/services/qualification-types/qualification-type.service';
import { IQualificationZone, ISubZone, IZone } from 'src/app/providers/services/zones/zones.interfaces';
import { ZonesService } from 'src/app/providers/services/zones/zones.service';

@Component({
  selector: 'pmf-subzone-modal-form',
  templateUrl: './subzone-modal-form.component.html',
  styleUrls: ['./subzone-modal-form.component.scss'],
})
export class SubzoneModalFormComponent implements OnInit {
  @Input() visible = false;
  @Input() subZoneId = 0;
  @Input() zone: IZone;
  @Output() closeModal = new EventEmitter<boolean>();
  zoneForm: FormGroup;
  qualificationsSubZone: Array<IQualificationZone> = [];
  qualificationsType: Array<IQualificationType> = [];
  btnSaveLabel = 'Agregar zona';
  loading = false;
  validationMessages = {
    name: [
      { type: 'required', message: 'Ingresa un nombre.' },
      { type: 'minlength', message: 'Nombre de zona debe ser mayor a 1 caracter.' },
      { type: 'pattern', message: 'El nombre solo debe contener letras.' },
    ],
    isActive: [{ type: 'required', message: 'Selecciona un estado.' }],
    description: [
      { type: 'required', message: 'Ingresa una descripción.' },
      { type: 'maxlength', message: 'La descripción debe contener máximo 200 caracteres.' },
    ],
  };

  constructor(
    private qualificationTypeService: QualificationTypeService,
    private zoneService: ZonesService,
    private notificationService: NotificationService,
  ) {
    this.zoneForm = new FormGroup({
      name: new FormControl(
        '',
        Validators.compose([
          Validators.minLength(1),
          Validators.required,
          // eslint-disable-next-line @typescript-eslint/quotes
          Validators.pattern("^[a-zA-Z'ñÑáéíóúÁÉÍÓÚ][a-zA-Z 'ñÑáéíóúÁÉÍÓÚ]*$"),
        ]),
      ),
      isActive: new FormControl('', Validators.required),
      qualifications: new FormControl('', Validators.required),
      description: new FormControl('', Validators.compose([Validators.maxLength(200), Validators.required])),
    });
  }

  ngOnInit(): void {
    this.loadQalificationsType();
    this.zoneForm.patchValue({ name: '', isActive: '1', qualifications: [], description: '' });
    if (this.subZoneId > 0) {
      //Edit pathValues
    }
  }

  closeModalForm(): void {
    this.closeModal.emit(!this.visible);
  }

  createZone(): void {
    const subZone: ISubZone = {
      name: this.zoneForm.value.name,
      zoneId: this.zone.id,
      description: this.zoneForm.value.description,
      isEnabled: this.zoneForm.value.isActive === '1' ? true : false,
    };
    this.loading = true;
    this.zoneService
      .createZoneWithQualifications(subZone, this.qualificationsSubZone)
      .subscribe((response: ISubZone) => {
        this.loading = false;
        this.closeModalForm();
        this.notificationService.fire(
          'success',
          'La sub-zona ha sido creada con éxito',
          `Se acaba de crear la sub-zona "${response.name}" en el sistema`,
          true,
          6000,
        );
      });
  }

  toggleQualificationType(event): void {
    const qualificationType = event.itemValue;
    const selectedQualificationsType = event.value;
    if (qualificationType) {
      const add = event.value.find((x) => x.id === qualificationType.id) ? true : false;
      if (add) {
        const qualificationSubZone: IQualificationZone = {
          id: qualificationType.id,
          name: qualificationType.name,
          codeCommandCentre: '',
          isActive: true,
        };
        this.qualificationsSubZone.push(qualificationSubZone);
      } else {
        const indexQualificationSubZone = this.qualificationsSubZone.findIndex((x) => x.id === qualificationType.id);
        this.qualificationsSubZone.splice(indexQualificationSubZone, 1);
      }
    } else {
      this.qualificationsSubZone = this.qualificationsSubZone.filter((x) =>
        selectedQualificationsType.find((y) => x.id === y.id),
      );
    }
  }

  addCommandCentreCode(event) {
    const code = event.currentTarget.value;
    const id = parseInt(event.currentTarget.id, 10);
    this.qualificationsSubZone = this.qualificationsSubZone.map((item) => {
      if (item.id === id) {
        item.codeCommandCentre = code;
      }
      return item;
    });
  }

  private loadQalificationsType() {
    this.qualificationTypeService.getAllActives().subscribe((response: IQualificationTypeResponse) => {
      this.qualificationsType = response;
    });
  }
}
