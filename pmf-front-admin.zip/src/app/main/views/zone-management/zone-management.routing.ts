import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/providers/guards/auth.guard';
import { ZoneManagementComponent } from './zone-management.component';

const routes: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    component: ZoneManagementComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ZoneManagementRoutingModule {}
