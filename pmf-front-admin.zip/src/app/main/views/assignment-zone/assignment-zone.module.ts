import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssignmentZoneRoutingModule } from './assignment-zone.routing';

@NgModule({
  declarations: [],
  imports: [CommonModule, AssignmentZoneRoutingModule],
})
export class AssignmentZoneModule {}
