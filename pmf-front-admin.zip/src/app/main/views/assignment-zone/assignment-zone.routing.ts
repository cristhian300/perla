import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignmentZoneComponent } from './assignment-zone.component';

const routes: Routes = [
  {
    path: '',
    component: AssignmentZoneComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssignmentZoneRoutingModule {}
