import { Component } from '@angular/core';

@Component({
  selector: 'pmf-assignment-zone',
  templateUrl: './assignment-zone.component.html',
  styleUrls: ['./assignment-zone.component.scss'],
})
export class AssignmentZoneComponent {}
