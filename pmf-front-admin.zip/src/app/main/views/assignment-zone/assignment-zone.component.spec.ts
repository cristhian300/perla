import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignmentZoneComponent } from './assignment-zone.component';

describe('AssignmentZoneComponent', () => {
  let component: AssignmentZoneComponent;
  let fixture: ComponentFixture<AssignmentZoneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AssignmentZoneComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignmentZoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
