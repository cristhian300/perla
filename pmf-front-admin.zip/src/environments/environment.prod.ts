export const environment = {
  production: true,
  bffBaseUrl: 'https://scl0edpmf02.americas.ent.bhpbilliton.net/pmf-bff/ws',
};
