import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SharedDataService {
  // Share Module Title
  titleObj: any = { title: '', subtitle: '' };
  titleObjSubject$ = new BehaviorSubject<any>(this.titleObj);
  currentTitleObj = this.titleObjSubject$.asObservable();

  async setTitleObj(titleObj: any) {
    this.titleObjSubject$.next(titleObj);
  }
}
