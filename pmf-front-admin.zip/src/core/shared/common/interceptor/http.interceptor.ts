import { Injectable } from '@angular/core';
import { HttpRequest, HttpInterceptor, HttpHandler } from '@angular/common/http';
import { BehaviorSubject, throwError } from 'rxjs';
import { mergeMap, catchError, switchMap, filter, take } from 'rxjs/operators';
import { Router } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { environment } from 'src/environments/environment';
import { ApiService } from '../../../../app/providers/services/api/api.service';
import { LocalStorageService } from '../services/storage/local-storage.service';
import { AuthService } from 'src/app/providers/services/auth/auth.service';
import { CustomsValidators } from '../../helpers/util/custom-validators';

@Injectable()
export class TokenInterceptorInterceptor implements HttpInterceptor {
  private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(
    private readonly apiService: ApiService,
    private readonly authService: AuthService,
    private readonly oauthService: OAuthService,
    private readonly localStorageService: LocalStorageService,
    private readonly router: Router,
  ) {
    // TokenInterceptor
  }

  intercept(req: HttpRequest<any>, next: HttpHandler) {
    const tokenizedReq = (req.headers.get('Authorization') && req) || this.addToken(req, this.getAccessToken());

    return next.handle(tokenizedReq).pipe(
      catchError((err) => {
        if (err.status === 401) {
          if (err.error.message === 'HTTP 401 Unauthorized' || err.error instanceof Blob) {
            if (!this.isRefreshing) {
              this.isRefreshing = true;
              this.refreshTokenSubject.next(null);
              const item = {
                pmrToken: this.localStorageService.getItem('Token'),
                refreshToken: this.localStorageService.getItem('RefreshToken'),
              };
              const urlBuilder = `${environment.bffBaseUrl}/pmf/auth/refresh`;
              return CustomsValidators.isValidUrl(urlBuilder)
                ? this.apiService.post(urlBuilder, item).pipe(
                    mergeMap((data: any) => {
                      if (data !== undefined || data != null) {
                        this.localStorageService.setItem('Token', data.PMFToken);
                        this.localStorageService.setItem('RefreshToken', data.RefreshToken);
                        this.isRefreshing = false;
                        this.refreshTokenSubject.next(data.PMFToken);
                        return next.handle(this.addToken(req, data.PMFToken));
                      } else {
                        // Logout from account
                        this.authService.logout().subscribe(
                          () => {
                            this.localStorageService.clear();
                            this.oauthService.logOut();
                          },
                          () => {
                            this.localStorageService.clear();
                            this.oauthService.logOut();
                          },
                        );
                      }
                    }),
                  )
                : throwError(CustomsValidators.msgNotValidUrl);
            } else {
              return this.refreshTokenSubject.pipe(
                filter((token) => token != null),
                take(1),
                switchMap(() => next.handle(this.addToken(req, this.localStorageService.getItem('Token')))),
              );
            }
          }
        }
        return throwError(err);
      }),
    );
  }

  private addToken(request: HttpRequest<any>, token: string) {
    return request.clone({
      setHeaders: {
        // eslint-disable-next-line @typescript-eslint/naming-convention
        'Cache-Control': 'no-cache',
        pragma: 'no-cache',
        expires: 'Sat, 01 Jan 2000 00:00:00 GMT',
        // eslint-disable-next-line @typescript-eslint/naming-convention
        'If-Modified-Since': '0',
        authorization: `Bearer ${token}`,
      },
    });
  }

  private getAccessToken(): string {
    return this.localStorageService.getItem('Token') || this.oauthService.getAccessToken();
  }
}
