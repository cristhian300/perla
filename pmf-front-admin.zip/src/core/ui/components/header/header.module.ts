import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header.component';
import { RouterModule } from '@angular/router';
import { BreadcrumbsModule } from 'src/core/ui/components/breadcrumbs/breadcrumbs.module';

@NgModule({
  declarations: [HeaderComponent],
  imports: [CommonModule, RouterModule, BreadcrumbsModule],
  exports: [HeaderComponent],
})
export class HeaderModule {}
