import { Component, Input } from '@angular/core';
import { LocalStorageService } from 'src/core/shared/common/services/storage/local-storage.service';

@Component({
  selector: 'pmf-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  @Input() showLogo = true;
  @Input() showLogout = true;
  @Input() options: any[] = [];
  @Input() optionsTop: any[] = [];
  @Input() initials = '';

  constructor(private readonly localStorageService: LocalStorageService ) {

    const currentUser = JSON.parse(  this.localStorageService.getItem("currentUser") )
    const Name =  currentUser.name
  
         let nameDiv = Name.split(',',2) 
    
         const  apellido = nameDiv[0].trim().toUpperCase( )
         const  nombre = nameDiv[1].trim().toUpperCase( )

        const oneLetterapellido = apellido.charAt(0)
        const oneLetternombre = nombre.charAt(0)
               
      this.initials = oneLetterapellido + oneLetternombre;

           
} 

}

