export interface IBreadcrum {
  label?: string;
  url?: string;
}

export type IBreadcrums = Array<IBreadcrum>;
