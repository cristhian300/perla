import { Component, Input } from '@angular/core';
import { IBreadcrums } from './breadcrumbs.interface';

@Component({
  selector: 'pmf-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss'],
})
export class BreadcrumbsComponent {
  // eslint-disable-next-line @typescript-eslint/naming-convention
  public static ROUTE_DATA_BREADCRUMB = 'breadcrumb';
  @Input() options: IBreadcrums = [];
  @Input() home = '';
}
