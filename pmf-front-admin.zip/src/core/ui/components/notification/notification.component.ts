import { Component, Input } from '@angular/core';

@Component({
  selector: 'pmf-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
})
export class NotificationComponent {
  @Input() title = '';
  @Input() subtitle = '';
  @Input() severity: string;

  states = {
    success: 'notifications notifications--success notifications--hid transition',
    failure: 'notifications notifications--failure notifications--hid transition',
    hide: 'notifications notifications--hide notifications--hid transition',
  };

  close() {
    this.severity = 'hide';
  }
}
