import { Component } from '@angular/core';

@Component({
  selector: 'pmf-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.scss'],
})
export class TopBarComponent {}
