import { Component, Input } from '@angular/core';

@Component({
  selector: 'pmf-cardmenu',
  templateUrl: './cardmenu.component.html',
  styleUrls: ['./cardmenu.component.scss'],
})
export class CardmenuComponent {
  @Input() cards: any[] = [];
}
