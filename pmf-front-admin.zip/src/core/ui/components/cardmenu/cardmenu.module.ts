import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardmenuComponent } from './cardmenu.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [CardmenuComponent],
  imports: [CommonModule, RouterModule],
  exports: [CardmenuComponent],
})
export class CardmenuModule {}
