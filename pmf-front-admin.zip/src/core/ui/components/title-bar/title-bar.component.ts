import { Component, Input } from '@angular/core';

@Component({
  selector: 'pmf-title-bar',
  templateUrl: './title-bar.component.html',
  styleUrls: ['./title-bar.component.scss'],
})
export class TitleBarComponent {
  @Input() title = '';
  @Input() subtitle = '';
}
