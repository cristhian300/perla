import { Component, Input } from '@angular/core';

@Component({
  selector: 'pmf-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
})
export class ButtonComponent {
  @Input() label = '';
  @Input() icon = '';
  @Input() iconPos = 'right';
  @Input() cssClass = 'btn';
  @Input() loading = false;
  @Input() disabled = false;
  @Input() type = 'button';
}
