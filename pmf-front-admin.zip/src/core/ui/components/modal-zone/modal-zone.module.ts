import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalZoneComponent } from './modal-zone.component';
import { ButtonModule } from 'src/core/ui/components/button/button.module';

@NgModule({
  declarations: [ModalZoneComponent],
  imports: [CommonModule, ButtonModule],
  exports: [ModalZoneComponent],
})
export class ModalZoneModule {}
