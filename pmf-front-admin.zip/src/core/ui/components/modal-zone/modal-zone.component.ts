import { Component } from '@angular/core';

@Component({
  selector: 'pmf-modal-zone',
  templateUrl: './modal-zone.component.html',
  styleUrls: ['./modal-zone.component.scss'],
})
export class ModalZoneComponent {}
