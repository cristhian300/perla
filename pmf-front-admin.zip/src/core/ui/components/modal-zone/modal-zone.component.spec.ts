import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalZoneComponent } from './modal-zone.component';

describe('ModalZoneComponent', () => {
  let component: ModalZoneComponent;
  let fixture: ComponentFixture<ModalZoneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ModalZoneComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalZoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
